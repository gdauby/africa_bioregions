# African bioregions mapping

This repository shares the shapefiles of biogeographical regions as defined in the paper:

*Beyond trees: biogeographical regionalization of tropical Africa*

Vincent Droissart, Gilles Dauby, Olivier J. Hardy, Vincent Deblauwe, David J. Harris, Steven Janssens, Barbara A. Mackinder, Anne-Blach Overgaard, Bonaventure Sonké, Marc S.M. Sosef, Tariq Stévart, Jens-Christian Svenning, Jan J. Wieringa, Thomas L.P. Couvreur

Journal of biogeography 2018

