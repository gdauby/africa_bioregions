

if(!any(rownames(installed.packages())=="sf")) install.packages("sf")
library(sf)




